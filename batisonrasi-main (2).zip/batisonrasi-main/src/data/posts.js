export const posts = [
  {
    slug: 'artan-servet-esitsizligi-ve-demokratik-kapitalizmin-sonbahari',
    title: 'Artan Servet Eşitsizliği ve Demokratik Kapitalizmin Sonbaharı',
    excerpt: 'Liberal demokrasinin günümüzdeki krizi, servet eşitsizliği ve sıkışan orta sınıflar üzerinden ele alınıyor.',
    authors: 'Mustafa Kutlay, Ziya Öniş ve Mehmet Ali Demir',
    date: '1 Aralık 2025',
    read: '14 dakika',
    category: 'Siyasi İktisat',
    theme: 'wealth',
    image: '/images/posts/esitsizlik-demokrasi.jpg',
    imageAlt: 'Manila’da nehir kıyısındaki gecekondular ve arka planda yükselen modern gökdelenler; servet eşitsizliğini simgeleyen görsel.'
  },
  {
    slug: 'brics-2025-rio-zirvesinin-ardindan',
    title: 'BRICS 2025 Rio Zirvesinin Ardından',
    excerpt: 'Rio Zirvesi üzerinden BRICS’in genişleyen yapısı, Küresel Güney ve yeni küresel yönetişim tartışılıyor.',
    authors: 'Ziya Öniş ve Mehmet Ali Demir',
    date: '1 Ağustos 2025',
    read: '12 dakika',
    category: 'Küresel Yönetişim',
    theme: 'brics',
    image: '/images/posts/brics-rio.jpg',
    imageAlt: 'Rio de Janeiro’nun kıyı şeridine ve şehre yukarıdan bakış.'
  }
];
